"use strict";(()=>{var S="https://application.trueward.guru",l=S,c=null,o=null,g=null,u=null,T="banner",H="",d=new Set,M=new Map,v=null,C=document.getElementById("app"),s=t=>document.getElementById(t),i=t=>String(t??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),j=null;function h(t,e="ok"){let n=s("toast");n.textContent=t,n.className=`toast ${e}`,n.hidden=!1,j&&clearTimeout(j),j=setTimeout(()=>n.hidden=!0,3200)}async function R(t,e){try{await navigator.clipboard.writeText(t),h(`${e} copied`)}catch{h("Couldn't copy \u2014 click into the panel and try again.","error")}}var p=class extends Error{constructor(n,a,r){super(n);this.status=a;this.body=r}status;body};async function q(){try{return(await chrome.cookies.get({url:l,name:"tw_device"}))?.value??null}catch{return null}}async function k(t){c=t,t?await chrome.storage.local.set({auth:t}):await chrome.storage.local.remove(["auth"])}async function E(t=!1){if(!c||!t&&c.expiresAt-Date.now()/1e3>60)return;let e=await fetch(`${l}/api/ext/refresh`,{method:"POST",headers:await L(!1),body:JSON.stringify({refreshToken:c.refreshToken})});if(!e.ok)throw await k(null),new p("Your session ended \u2014 sign in again.",401,{});let n=await e.json();await k({...n,email:n.email??c.email})}async function L(t=!0){let e={"Content-Type":"application/json"},n=await q();return n&&(e["x-trueward-device"]=n),t&&c&&(e.Authorization=`Bearer ${c.accessToken}`),e}async function b(t,e={},n=!1){await E();let a=await fetch(`${l}${t}`,{method:e.method??(e.json===void 0?"GET":"POST"),headers:await L(),body:e.json===void 0?void 0:JSON.stringify(e.json)});if(a.status===401&&c&&!n)return await E(!0),b(t,e,!0);let r=await a.json().catch(()=>({}));if(!a.ok)throw new p(String(r.error??`Request failed (${a.status})`),a.status,r);return r}function N(t,e,n){C.innerHTML=`
    <section class="card notice">
      <h3>${i(t)}</h3>
      <p class="muted">${i(e)}</p>
      ${n?`<button class="primary" id="notice-go">${i(n.label)}</button>`:""}
      <button id="notice-retry">Try again</button>
    </section>`,n&&(s("notice-go").onclick=()=>chrome.tabs.create({url:n.url})),s("notice-retry").onclick=()=>{I()}}function f(t){s("who").textContent="",s("signout").hidden=!0,C.innerHTML=`
    <section class="card">
      <h3>Sign in</h3>
      <p class="muted small">Your Trueward account \u2014 the same email and password as the application.</p>
      <form id="login">
        <input id="email" type="email" placeholder="Email" autocomplete="username" required />
        <input id="password" type="password" placeholder="Password" autocomplete="current-password" required />
        ${t?`<p class="error small">${i(t)}</p>`:""}
        <button class="primary" type="submit">Sign in</button>
      </form>
      <details class="small muted"><summary>Server</summary>
        <input id="base" value="${i(l)}" />
      </details>
    </section>`,s("login").onsubmit=async e=>{e.preventDefault();let n=(s("base").value.trim()||S).replace(/\/+$/,""),a=URL.canParse(n)?new URL(n):null;if(a&&!a.hostname.endsWith("trueward.guru")&&!await chrome.permissions.request({origins:[`${a.protocol}//${a.hostname}/*`]}).catch(()=>!1))return f(`Chrome needs permission to reach ${a.hostname}.`);n!==l&&(l=n,await chrome.storage.local.set({base:l}));try{let r=await fetch(`${l}/api/ext/login`,{method:"POST",headers:await L(!1),body:JSON.stringify({email:s("email").value,password:s("password").value})}),m=await r.json().catch(()=>({}));if(!r.ok)return f(m.error??"Couldn't sign in.");await k(m),await I()}catch{f("Couldn't reach Trueward.")}}}function B(){C.innerHTML=`
    <section class="card">
      <label class="label" for="profile">Profile</label>
      <select id="profile"></select>
      <div id="contact" class="fields"></div>
    </section>
    <section class="card">
      <div class="row">
        <h3>Jobs</h3><span class="grow"></span>
        <button id="sync" class="small">Sync sheet</button>
      </div>
      <div id="sheet"></div>
      <input id="search" placeholder="Search jobs\u2026" />
      <div id="jobs" class="jobs"></div>
      <div class="row gen">
        <select id="template"></select>
        <label class="small"><input type="checkbox" id="regen" /> Redo</label>
        <span class="grow"></span>
        <button id="generate" class="primary">Generate</button>
      </div>
    </section>
    <section class="card" id="detail-card" hidden>
      <div id="detail"></div>
      <label class="label" for="question">Screening question</label>
      <textarea id="question" rows="3" placeholder="e.g. Why do you want to work here?"></textarea>
      <div class="row"><span class="grow"></span><button id="ask">Ask</button></div>
      <div id="answers"></div>
    </section>`,s("profile").onchange=async t=>{g=t.target.value,await chrome.storage.local.set({profileId:g}),u=null,d.clear(),await w()},s("search").oninput=t=>{H=t.target.value.trim().toLowerCase(),A()},s("template").onchange=async t=>{T=t.target.value,await chrome.storage.local.set({template:T})},s("sync").onclick=()=>{J()},s("generate").onclick=()=>{Y()},s("ask").onclick=()=>{Z()},s("contact").onclick=t=>{let e=t.target.closest("[data-copy]");e&&R(e.dataset.copy,e.dataset.label??"Value")},s("jobs").onclick=t=>{let e=t.target,n=e.closest("input[data-check]");if(n){n.checked?d.add(n.dataset.check):d.delete(n.dataset.check),x();return}let a=e.closest("[data-select]");a&&W(a.dataset.select)},s("detail").onclick=t=>{let e=t.target.closest("[data-action]");if(!e)return;let n=e.dataset.action;if(n==="track"&&V(),n==="download"&&O(),n==="open"){let a=o?.jobs.find(r=>r.id===u);a?.url&&chrome.tabs.create({url:a.url})}},s("answers").onclick=t=>{let e=t.target.closest("[data-answer]");e&&R(e.dataset.answer,"Answer")}}function _(){if(!o)return;s("who").textContent=o.me.email,s("signout").hidden=!1;let t=s("profile");t.innerHTML=o.profiles.length?o.profiles.map(n=>`<option value="${i(n.id)}" ${n.id===o.profile?.id?"selected":""}>${i(n.name)}</option>`).join(""):"<option>No profile assigned to you</option>";let e=s("template");e.innerHTML=o.templates.map(n=>`<option value="${i(n.id)}" ${n.id===T?"selected":""}>${i(n.label)}</option>`).join(""),F(),z(),A(),x(),U()}var G=[["fullName","Full name"],["first","First name"],["last","Last name"],["email","Email"],["phone","Phone"],["address","Address"],["city","City"],["state","State"],["postalCode","ZIP"],["country","Country"],["linkedin","LinkedIn"],["github","GitHub"],["birthday","Birthday"]];function F(){let t=o?.profile;if(!t){s("contact").innerHTML='<p class="muted small">Pick a profile to see its details.</p>';return}let e=t.fullName.trim().split(/\s+/),n={...t,first:e.length>1?e.slice(0,-1).join(" "):t.fullName,last:e.length>1?e[e.length-1]:null};s("contact").innerHTML=G.filter(([a])=>n[a]).map(([a,r])=>`
      <div class="field">
        <span class="label">${i(r)}</span>
        <span class="value" title="${i(n[a])}">${i(n[a])}</span>
        <button class="copy" data-copy="${i(n[a])}" data-label="${i(r)}" aria-label="Copy ${i(r)}">Copy</button>
      </div>`).join("")}function z(){let t=o?.sheet;if(t){s("sheet").innerHTML=t.last_error?`<p class="error small">${i(t.last_error)}</p>`:`<p class="muted small">${o.jobs.length} job${o.jobs.length===1?"":"s"}${t.last_synced_at?` \xB7 synced ${new Date(t.last_synced_at).toLocaleString()}`:""}</p>`;return}s("sheet").innerHTML=`
    <p class="muted small">Connect your Google Sheet of jobs (No, Title, Company, URL, JD), shared as \u201CAnyone with the link can view\u201D.</p>
    <div class="row"><input id="sheet-url" placeholder="https://docs.google.com/spreadsheets/d/\u2026" /><button id="connect" class="primary">Connect</button></div>`,s("connect").onclick=()=>{J(s("sheet-url").value)}}function P(t){return t?t.tracked?'<span class="pill green">Applied</span>':t.status==="queued"?'<span class="pill">Waiting</span>':t.status==="running"?'<span class="pill blue spin">Generating</span>':t.status==="failed"?`<span class="pill red" title="${i(t.error)}">Failed</span>`:t.valid?'<span class="pill blue">Ready</span>':'<span class="pill amber">Needs a fix</span>':""}function A(){let t=(o?.jobs??[]).filter(e=>!H||`${e.no} ${e.title} ${e.company??""}`.toLowerCase().includes(H));s("jobs").innerHTML=t.length?t.map(e=>`
      <div class="job ${e.id===u?"selected":""}">
        <input type="checkbox" data-check="${i(e.id)}" ${d.has(e.id)?"checked":""} aria-label="Select job ${i(e.no)}" />
        <div class="job-main" data-select="${i(e.id)}">
          <div class="job-title"><span class="no">#${i(e.no)}</span> ${i(e.title)}</div>
          <div class="muted small">${i(e.company??"")}</div>
        </div>
        ${P(e.resume)}
      </div>`).join(""):`<p class="muted small">${o?.sheet?"No jobs match.":""}</p>`}function x(){let t=s("generate");t.textContent=d.size?`Generate (${d.size})`:"Generate",t.disabled=!d.size||!o?.profile}function U(){let t=o?.jobs.find(a=>a.id===u);if(s("detail-card").hidden=!t,!t)return;let e=t.resume,n=e?.status==="ready";s("detail").innerHTML=`
    <div class="row"><h3 class="grow">#${i(t.no)} ${i(t.title)}</h3>${P(e)}</div>
    <p class="muted small">${i(t.company??"")}</p>
    ${e?e.status==="failed"?`<p class="error small">${i(e.error??"Generation failed.")} Tick it and Generate with \u201CRedo\u201D.</p>`:n?"":'<p class="muted small">Its resume is on the way.</p>':'<p class="muted small">No resume for this profile yet \u2014 tick it and Generate.</p>'}
    <div class="row wrap">
      <button class="primary" data-action="track" ${n?"":"disabled"}>${e?.tracked?"Download again":"Download &amp; track"}</button>
      <button data-action="download" ${n?"":"disabled"}>Download only</button>
      ${t.url?'<button data-action="open">Open posting</button>':""}
    </div>
    <div id="apply-note"></div>`,D()}function D(){let t=M.get(u??"")??[];s("answers").innerHTML=t.map(e=>`
      <div class="answer">
        <div class="q">${i(e.question)}</div>
        <div class="a">${i(e.answer)}</div>
        <button class="copy" data-answer="${i(e.answer)}">Copy answer</button>
      </div>`).join("")}async function w(){try{o=await b(`/api/ext/state${g?`?profileId=${encodeURIComponent(g)}`:""}`),g=o.profile?.id??null,_();let t=o.jobs.some(e=>e.resume&&(e.resume.status==="queued"||e.resume.status==="running"));t&&!v&&(v=setInterval(()=>{w()},5e3)),!t&&v&&(clearInterval(v),v=null)}catch(t){y(t)}}async function W(t){let e=t!==u;u=t,A(),U();let n=o?.jobs.find(a=>a.id===t);e&&n?.url&&await chrome.tabs.create({url:n.url,active:!0})}async function J(t){let e=s("sync");e.disabled=!0;try{let n=await b("/api/ext/sheet",{json:t?{url:t}:{}});h(`${n.total} jobs${n.added?`, ${n.added} new`:""}`),await w()}catch(n){y(n)}finally{e.disabled=!1}}async function Y(){if(!o?.profile||!d.size)return;let t=s("generate");t.disabled=!0;try{let e=await b("/api/ext/generate",{json:{profileId:o.profile.id,sheetJobIds:[...d],template:T,regenerate:s("regen").checked}});h([e.started?`${e.started} generating`:"",e.queued?`${e.queued} waiting`:"",e.skipped?`${e.skipped} already done`:""].filter(Boolean).join(", ")||"Nothing to do"),d.clear(),await w()}catch(e){y(e)}finally{x()}}function $(t){let e=document.getElementById("apply-note");e&&(e.innerHTML=t)}async function V(){let t=o?.jobs.find(e=>e.id===u);if(t?.resume){$('<p class="muted small">Recording the application\u2026</p>');try{let e=await b("/api/ext/apply",{json:{resumeJobId:t.resume.id}});e.fileUrl?await chrome.downloads.download({url:e.fileUrl,filename:e.fileName}):await O(),$(`<p class="ok small">${e.alreadyTracked?"Already in Applications \u2014 downloaded again.":"Downloaded, and tracked in Applications."}</p>`),await w()}catch(e){if(e instanceof p&&e.status===409){$(`<p class="error small">${i(e.message)}</p><button data-action="download">Download without tracking</button>`);return}$(""),y(e)}}}async function O(){let t=o?.jobs.find(e=>e.id===u);if(t?.resume)try{await E();let e=await fetch(`${l}/api/resume-jobs/${t.resume.id}/pdf`,{headers:await L()});if(!e.ok){let m=await e.json().catch(()=>({}));throw new p(m.error??"The PDF couldn't be made.",e.status,{})}let n=e.headers.get("content-disposition")??"",a=decodeURIComponent(n.match(/filename\*=UTF-8''([^;]+)/)?.[1]??"resume.pdf"),r=URL.createObjectURL(await e.blob());await chrome.downloads.download({url:r,filename:a.replace(/[\\/:*?"<>|]+/g,"")}),setTimeout(()=>URL.revokeObjectURL(r),6e4)}catch(e){y(e)}}async function Z(){let t=o?.jobs.find(r=>r.id===u),e=s("question"),n=e.value.trim();if(!t?.resume||!n)return;let a=s("ask");a.disabled=!0,a.textContent="Thinking\u2026";try{let r=M.get(t.id)??[],m=await b("/api/ext/ask",{json:{resumeJobId:t.resume.id,question:n,history:r}});M.set(t.id,[...r,{question:n,answer:m.answer}]),e.value="",D()}catch(r){y(r)}finally{a.disabled=!1,a.textContent="Ask"}}function y(t){if(t instanceof p)return t.status===401?f("Your session ended \u2014 sign in again."):t.status===403&&/device/i.test(t.message)?N("This browser isn't approved yet",t.message,{label:"Request access",url:`${l}/access`}):h(t.message,"error");h("Couldn't reach Trueward.","error")}async function I(){let t=await chrome.storage.local.get(["auth","base","profileId","template"]);if(l=t.base||S,c=t.auth??null,g=t.profileId??null,T=t.template??"banner",!await q())return N("Open Trueward once in this browser","The extension uses this browser's Trueward device id, which the site sets on your first visit. Open it, then try again.",{label:"Open Trueward",url:l});if(!c)return f();B(),await w()}s("signout").onclick=async()=>{await k(null),o=null,f()};I();})();
